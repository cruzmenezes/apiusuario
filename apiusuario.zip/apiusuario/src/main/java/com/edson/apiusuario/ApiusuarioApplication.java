package com.edson.apiusuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiusuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiusuarioApplication.class, args);
	}

}
